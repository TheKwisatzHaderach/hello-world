/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//raiderdrive.tosm.ttu.edu/users/stcollin/CollinsSterlingHW5/Hw5/MFU.v";
static int ng1[] = {0, 0, 0, 0};
static unsigned int ng2[] = {2U, 0U};
static unsigned int ng3[] = {5U, 0U};
static int ng4[] = {1, 0, 0, 0};
static unsigned int ng5[] = {8U, 0U};
static unsigned int ng6[] = {10U, 0U};
static unsigned int ng7[] = {12U, 0U};
static unsigned int ng8[] = {14U, 0U};
static unsigned int ng9[] = {0U, 0U};
static unsigned int ng10[] = {16U, 0U};
static unsigned int ng11[] = {17U, 0U};
static unsigned int ng12[] = {7U, 0U};
static unsigned int ng13[] = {25U, 0U};
static const char *ng14 = "error in MFU";
static int ng15[] = {0, 0};
static int ng16[] = {1, 0};
static int ng17[] = {31, 0};



static void Initial_36_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    xsi_set_current_line(36, ng0);

LAB2:    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 10296);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);
    t3 = (t0 + 10136);
    xsi_vlogvar_assign_value(t3, t1, 1, 0, 1);
    t4 = (t0 + 10456);
    xsi_vlogvar_assign_value(t4, t1, 2, 0, 1);
    t5 = (t0 + 9976);
    xsi_vlogvar_assign_value(t5, t1, 3, 0, 1);
    t6 = (t0 + 9816);
    xsi_vlogvar_assign_value(t6, t1, 4, 0, 32);

LAB1:    return;
}

static void Always_42_1(char *t0)
{
    char t9[16];
    char t10[16];
    char t11[16];
    char t73[8];
    char t74[8];
    char t75[8];
    char t76[8];
    char t77[8];
    char t78[8];
    char t86[8];
    char t92[8];
    char t122[8];
    char t136[8];
    char t147[8];
    char t156[8];
    char t172[8];
    char t180[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    char *t36;
    char *t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    int t48;
    int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    char *t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    char *t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    char *t134;
    char *t135;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    char *t144;
    char *t145;
    char *t146;
    char *t148;
    char *t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    char *t157;
    char *t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    char *t171;
    char *t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    char *t179;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    char *t184;
    char *t185;
    char *t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    char *t194;
    char *t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    int t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;

LAB0:    t1 = (t0 + 11784U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 12104);
    *((int *)t2) = 1;
    t3 = (t0 + 11816);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(42, ng0);

LAB5:    xsi_set_current_line(43, ng0);
    t4 = (t0 + 10296);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 10616);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 9416U);
    t3 = *((char **)t2);

LAB6:    t2 = ((char*)((ng2)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng6)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng7)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng8)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng9)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng10)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng11)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng12)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng13)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t8 == 1)
        goto LAB27;

LAB28:
LAB30:
LAB29:    xsi_set_current_line(57, ng0);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);

LAB31:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 9816);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng15)));
    memset(t73, 0, 8);
    t7 = (t5 + 4);
    t12 = (t6 + 4);
    t13 = *((unsigned int *)t5);
    t14 = *((unsigned int *)t6);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t12);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t7);
    t22 = *((unsigned int *)t12);
    t24 = (t20 | t22);
    t26 = (~(t24));
    t27 = (t19 & t26);
    if (t27 != 0)
        goto LAB74;

LAB71:    if (t24 != 0)
        goto LAB73;

LAB72:    *((unsigned int *)t73) = 1;

LAB74:    t23 = (t73 + 4);
    t28 = *((unsigned int *)t23);
    t29 = (~(t28));
    t30 = *((unsigned int *)t73);
    t31 = (t30 & t29);
    t32 = (t31 != 0);
    if (t32 > 0)
        goto LAB75;

LAB76:    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng15)));
    t4 = (t0 + 9976);
    xsi_vlogvar_assign_value(t4, t2, 0, 0, 1);

LAB77:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 9816);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 9816);
    t7 = (t6 + 72U);
    t12 = *((char **)t7);
    t21 = ((char*)((ng17)));
    xsi_vlog_generic_get_index_select_value(t73, 32, t5, t12, 2, t21, 32, 1);
    t23 = ((char*)((ng16)));
    memset(t74, 0, 8);
    t25 = (t73 + 4);
    t34 = (t23 + 4);
    t13 = *((unsigned int *)t73);
    t14 = *((unsigned int *)t23);
    t15 = (t13 ^ t14);
    t16 = *((unsigned int *)t25);
    t17 = *((unsigned int *)t34);
    t18 = (t16 ^ t17);
    t19 = (t15 | t18);
    t20 = *((unsigned int *)t25);
    t22 = *((unsigned int *)t34);
    t24 = (t20 | t22);
    t26 = (~(t24));
    t27 = (t19 & t26);
    if (t27 != 0)
        goto LAB81;

LAB78:    if (t24 != 0)
        goto LAB80;

LAB79:    *((unsigned int *)t74) = 1;

LAB81:    t37 = (t74 + 4);
    t28 = *((unsigned int *)t37);
    t29 = (~(t28));
    t30 = *((unsigned int *)t74);
    t31 = (t30 & t29);
    t32 = (t31 != 0);
    if (t32 > 0)
        goto LAB82;

LAB83:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng15)));
    t4 = (t0 + 10136);
    xsi_vlogvar_assign_value(t4, t2, 0, 0, 1);

LAB84:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 9416U);
    t4 = *((char **)t2);
    memset(t73, 0, 8);
    t2 = (t73 + 4);
    t5 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = (t13 >> 0);
    *((unsigned int *)t73) = t14;
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 0);
    *((unsigned int *)t2) = t16;
    t17 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t17 & 31U);
    t18 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t18 & 31U);
    t6 = ((char*)((ng2)));
    memset(t74, 0, 8);
    t7 = (t73 + 4);
    t12 = (t6 + 4);
    t19 = *((unsigned int *)t73);
    t20 = *((unsigned int *)t6);
    t22 = (t19 ^ t20);
    t24 = *((unsigned int *)t7);
    t26 = *((unsigned int *)t12);
    t27 = (t24 ^ t26);
    t28 = (t22 | t27);
    t29 = *((unsigned int *)t7);
    t30 = *((unsigned int *)t12);
    t31 = (t29 | t30);
    t32 = (~(t31));
    t33 = (t28 & t32);
    if (t33 != 0)
        goto LAB88;

LAB85:    if (t31 != 0)
        goto LAB87;

LAB86:    *((unsigned int *)t74) = 1;

LAB88:    memset(t75, 0, 8);
    t23 = (t74 + 4);
    t35 = *((unsigned int *)t23);
    t38 = (~(t35));
    t40 = *((unsigned int *)t74);
    t41 = (t40 & t38);
    t42 = (t41 & 1U);
    if (t42 != 0)
        goto LAB89;

LAB90:    if (*((unsigned int *)t23) != 0)
        goto LAB91;

LAB92:    t34 = (t75 + 4);
    t43 = *((unsigned int *)t75);
    t44 = *((unsigned int *)t34);
    t45 = (t43 || t44);
    if (t45 > 0)
        goto LAB93;

LAB94:    memcpy(t92, t75, 8);

LAB95:    memset(t122, 0, 8);
    t123 = (t92 + 4);
    t124 = *((unsigned int *)t123);
    t125 = (~(t124));
    t126 = *((unsigned int *)t92);
    t127 = (t126 & t125);
    t128 = (t127 & 1U);
    if (t128 != 0)
        goto LAB107;

LAB108:    if (*((unsigned int *)t123) != 0)
        goto LAB109;

LAB110:    t130 = (t122 + 4);
    t131 = *((unsigned int *)t122);
    t132 = *((unsigned int *)t130);
    t133 = (t131 || t132);
    if (t133 > 0)
        goto LAB111;

LAB112:    memcpy(t180, t122, 8);

LAB113:    t211 = (t180 + 4);
    t212 = *((unsigned int *)t211);
    t213 = (~(t212));
    t214 = *((unsigned int *)t180);
    t215 = (t214 & t213);
    t216 = (t215 != 0);
    if (t216 > 0)
        goto LAB125;

LAB126:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 9416U);
    t4 = *((char **)t2);
    memset(t73, 0, 8);
    t2 = (t73 + 4);
    t5 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = (t13 >> 0);
    *((unsigned int *)t73) = t14;
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 0);
    *((unsigned int *)t2) = t16;
    t17 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t17 & 31U);
    t18 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t18 & 31U);
    t6 = ((char*)((ng3)));
    memset(t74, 0, 8);
    t7 = (t73 + 4);
    t12 = (t6 + 4);
    t19 = *((unsigned int *)t73);
    t20 = *((unsigned int *)t6);
    t22 = (t19 ^ t20);
    t24 = *((unsigned int *)t7);
    t26 = *((unsigned int *)t12);
    t27 = (t24 ^ t26);
    t28 = (t22 | t27);
    t29 = *((unsigned int *)t7);
    t30 = *((unsigned int *)t12);
    t31 = (t29 | t30);
    t32 = (~(t31));
    t33 = (t28 & t32);
    if (t33 != 0)
        goto LAB131;

LAB128:    if (t31 != 0)
        goto LAB130;

LAB129:    *((unsigned int *)t74) = 1;

LAB131:    memset(t75, 0, 8);
    t23 = (t74 + 4);
    t35 = *((unsigned int *)t23);
    t38 = (~(t35));
    t40 = *((unsigned int *)t74);
    t41 = (t40 & t38);
    t42 = (t41 & 1U);
    if (t42 != 0)
        goto LAB132;

LAB133:    if (*((unsigned int *)t23) != 0)
        goto LAB134;

LAB135:    t34 = (t75 + 4);
    t43 = *((unsigned int *)t75);
    t44 = *((unsigned int *)t34);
    t45 = (t43 || t44);
    if (t45 > 0)
        goto LAB136;

LAB137:    memcpy(t92, t75, 8);

LAB138:    memset(t122, 0, 8);
    t123 = (t92 + 4);
    t124 = *((unsigned int *)t123);
    t125 = (~(t124));
    t126 = *((unsigned int *)t92);
    t127 = (t126 & t125);
    t128 = (t127 & 1U);
    if (t128 != 0)
        goto LAB150;

LAB151:    if (*((unsigned int *)t123) != 0)
        goto LAB152;

LAB153:    t130 = (t122 + 4);
    t131 = *((unsigned int *)t122);
    t132 = *((unsigned int *)t130);
    t133 = (t131 || t132);
    if (t133 > 0)
        goto LAB154;

LAB155:    memcpy(t180, t122, 8);

LAB156:    t211 = (t180 + 4);
    t212 = *((unsigned int *)t211);
    t213 = (~(t212));
    t214 = *((unsigned int *)t180);
    t215 = (t214 & t213);
    t216 = (t215 != 0);
    if (t216 > 0)
        goto LAB168;

LAB169:    xsi_set_current_line(68, ng0);
    t2 = ((char*)((ng15)));
    t4 = (t0 + 10456);
    xsi_vlogvar_assign_value(t4, t2, 0, 0, 1);

LAB170:
LAB127:    goto LAB2;

LAB7:    xsi_set_current_line(46, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    xsi_vlog_unsigned_add(t9, 33, t5, 32, t6, 32);
    t4 = (t0 + 9816);
    xsi_vlogvar_assign_value(t4, t9, 0, 0, 32);
    t7 = (t0 + 10296);
    xsi_vlogvar_assign_value(t7, t9, 32, 0, 1);
    goto LAB31;

LAB9:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    xsi_vlogtype_unsigned_bit_neg(t9, 33, t6, 32);
    xsi_vlog_unsigned_add(t10, 33, t5, 32, t9, 33);
    t4 = ((char*)((ng4)));
    xsi_vlog_unsigned_add(t11, 33, t10, 33, t4, 32);
    t7 = (t0 + 9816);
    xsi_vlogvar_assign_value(t7, t11, 0, 0, 32);
    t12 = (t0 + 10296);
    xsi_vlogvar_assign_value(t12, t11, 32, 0, 1);
    goto LAB31;

LAB11:    xsi_set_current_line(48, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    t13 = 0;

LAB35:    t14 = (t13 < 1);
    if (t14 == 1)
        goto LAB36;

LAB37:    t13 = 1;

LAB38:    t56 = (t13 < 2);
    if (t56 == 1)
        goto LAB39;

LAB44:    t67 = (t0 + 9816);
    xsi_vlogvar_assign_value(t67, t9, 0, 0, 32);
    t68 = (t0 + 10296);
    xsi_vlogvar_assign_value(t68, t9, 32, 0, 1);
    goto LAB31;

LAB13:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    t13 = 0;

LAB48:    t14 = (t13 < 1);
    if (t14 == 1)
        goto LAB49;

LAB50:    t13 = 1;

LAB51:    t52 = (t13 < 2);
    if (t52 == 1)
        goto LAB52;

LAB57:    t71 = (t0 + 9816);
    xsi_vlogvar_assign_value(t71, t9, 0, 0, 32);
    t72 = (t0 + 10296);
    xsi_vlogvar_assign_value(t72, t9, 32, 0, 1);
    goto LAB31;

LAB15:    xsi_set_current_line(50, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    t13 = 0;

LAB61:    t14 = (t13 < 1);
    if (t14 == 1)
        goto LAB62;

LAB63:    t13 = 1;

LAB64:    t33 = (t13 < 2);
    if (t33 == 1)
        goto LAB65;

LAB70:    t63 = (t0 + 9816);
    xsi_vlogvar_assign_value(t63, t9, 0, 0, 32);
    t66 = (t0 + 10296);
    xsi_vlogvar_assign_value(t66, t9, 32, 0, 1);
    goto LAB31;

LAB17:    xsi_set_current_line(51, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    xsi_vlogtype_unsigned_bit_neg(t9, 33, t5, 32);
    t4 = (t0 + 9816);
    xsi_vlogvar_assign_value(t4, t9, 0, 0, 32);
    t6 = (t0 + 10296);
    xsi_vlogvar_assign_value(t6, t9, 32, 0, 1);
    goto LAB31;

LAB19:    xsi_set_current_line(52, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    memcpy(t9, t5, 8);
    t4 = (t9 + 8);
    memset(t4, 0, 8);
    t6 = (t0 + 9816);
    xsi_vlogvar_assign_value(t6, t9, 0, 0, 32);
    t7 = (t0 + 10296);
    xsi_vlogvar_assign_value(t7, t9, 32, 0, 1);
    goto LAB31;

LAB21:    xsi_set_current_line(53, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9256U);
    t6 = *((char **)t4);
    xsi_vlog_unsigned_lshift(t9, 33, t5, 32, t6, 5);
    t4 = (t0 + 9816);
    xsi_vlogvar_assign_value(t4, t9, 0, 0, 32);
    t7 = (t0 + 10296);
    xsi_vlogvar_assign_value(t7, t9, 32, 0, 1);
    goto LAB31;

LAB23:    xsi_set_current_line(54, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9256U);
    t6 = *((char **)t4);
    xsi_vlog_unsigned_rshift(t9, 33, t5, 32, t6, 5);
    t4 = (t0 + 9816);
    xsi_vlogvar_assign_value(t4, t9, 0, 0, 32);
    t7 = (t0 + 10296);
    xsi_vlogvar_assign_value(t7, t9, 32, 0, 1);
    goto LAB31;

LAB25:    xsi_set_current_line(55, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    memcpy(t9, t5, 8);
    t4 = (t9 + 8);
    memset(t4, 0, 8);
    t6 = (t0 + 9816);
    xsi_vlogvar_assign_value(t6, t9, 0, 0, 32);
    t7 = (t0 + 10296);
    xsi_vlogvar_assign_value(t7, t9, 32, 0, 1);
    goto LAB31;

LAB27:    xsi_set_current_line(56, ng0);
    t4 = (t0 + 8936U);
    t5 = *((char **)t4);
    t4 = (t0 + 9096U);
    t6 = *((char **)t4);
    xsi_vlog_unsigned_add(t9, 33, t5, 32, t6, 32);
    t4 = (t0 + 10616);
    t7 = (t4 + 56U);
    t12 = *((char **)t7);
    xsi_vlog_unsigned_add(t10, 33, t9, 33, t12, 1);
    t21 = (t0 + 9816);
    xsi_vlogvar_assign_value(t21, t10, 0, 0, 32);
    t23 = (t0 + 10296);
    xsi_vlogvar_assign_value(t23, t10, 32, 0, 1);
    goto LAB31;

LAB32:    t31 = (t13 * 8);
    t32 = *((unsigned int *)t12);
    t33 = *((unsigned int *)t25);
    *((unsigned int *)t12) = (t32 | t33);
    t34 = (t5 + t31);
    t35 = (t31 + 4);
    t36 = (t5 + t35);
    t37 = (t6 + t31);
    t38 = (t31 + 4);
    t39 = (t6 + t38);
    t40 = *((unsigned int *)t34);
    t41 = (~(t40));
    t42 = *((unsigned int *)t36);
    t43 = (~(t42));
    t44 = *((unsigned int *)t37);
    t45 = (~(t44));
    t46 = *((unsigned int *)t39);
    t47 = (~(t46));
    t48 = (t41 & t43);
    t49 = (t45 & t47);
    t50 = (~(t48));
    t51 = (~(t49));
    t52 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t52 & t50);
    t53 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t53 & t51);
    t54 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t54 & t50);
    t55 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t55 & t51);

LAB34:    t13 = (t13 + 1);
    goto LAB35;

LAB33:    goto LAB34;

LAB36:    t15 = (t13 * 8);
    t4 = (t5 + t15);
    t7 = (t6 + t15);
    t12 = (t9 + t15);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t7);
    t18 = (t16 & t17);
    *((unsigned int *)t12) = t18;
    t19 = (t13 * 8);
    t20 = (t19 + 4);
    t21 = (t5 + t20);
    t22 = (t19 + 4);
    t23 = (t6 + t22);
    t24 = (t19 + 4);
    t25 = (t9 + t24);
    t26 = *((unsigned int *)t21);
    t27 = *((unsigned int *)t23);
    t28 = (t26 | t27);
    *((unsigned int *)t25) = t28;
    t29 = *((unsigned int *)t25);
    t30 = (t29 != 0);
    if (t30 == 1)
        goto LAB32;
    else
        goto LAB33;

LAB39:    t57 = (t13 * 8);
    t58 = (t9 + t57);
    *((unsigned int *)t58) = 0;
    t59 = (t57 + 4);
    t60 = (t9 + t59);
    *((unsigned int *)t60) = 0;
    t61 = (t13 < 1);
    if (t61 == 1)
        goto LAB40;

LAB42:    t64 = (t13 < 1);
    if (t64 == 1)
        goto LAB41;

LAB43:    t13 = (t13 + 1);
    goto LAB38;

LAB40:    t62 = (t57 + 4);
    t63 = (t5 + t62);
    *((unsigned int *)t58) = *((unsigned int *)t63);
    *((unsigned int *)t60) = *((unsigned int *)t63);
    goto LAB43;

LAB41:    t65 = (t57 + 4);
    t66 = (t6 + t65);
    *((unsigned int *)t58) = *((unsigned int *)t66);
    *((unsigned int *)t60) = *((unsigned int *)t66);
    goto LAB43;

LAB45:    t31 = (t13 * 8);
    t32 = *((unsigned int *)t12);
    t33 = *((unsigned int *)t25);
    *((unsigned int *)t12) = (t32 | t33);
    t34 = (t5 + t31);
    t35 = (t31 + 4);
    t36 = (t5 + t35);
    t37 = (t6 + t31);
    t38 = (t31 + 4);
    t39 = (t6 + t38);
    t40 = *((unsigned int *)t36);
    t41 = (~(t40));
    t42 = *((unsigned int *)t34);
    t48 = (t42 & t41);
    t43 = *((unsigned int *)t39);
    t44 = (~(t43));
    t45 = *((unsigned int *)t37);
    t49 = (t45 & t44);
    t46 = (~(t48));
    t47 = (~(t49));
    t50 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t50 & t46);
    t51 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t51 & t47);

LAB47:    t13 = (t13 + 1);
    goto LAB48;

LAB46:    goto LAB47;

LAB49:    t15 = (t13 * 8);
    t4 = (t5 + t15);
    t7 = (t6 + t15);
    t12 = (t9 + t15);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t7);
    t18 = (t16 | t17);
    *((unsigned int *)t12) = t18;
    t19 = (t13 * 8);
    t20 = (t19 + 4);
    t21 = (t5 + t20);
    t22 = (t19 + 4);
    t23 = (t6 + t22);
    t24 = (t19 + 4);
    t25 = (t9 + t24);
    t26 = *((unsigned int *)t21);
    t27 = *((unsigned int *)t23);
    t28 = (t26 | t27);
    *((unsigned int *)t25) = t28;
    t29 = *((unsigned int *)t25);
    t30 = (t29 != 0);
    if (t30 == 1)
        goto LAB45;
    else
        goto LAB46;

LAB52:    t53 = (t13 * 8);
    t58 = (t9 + t53);
    *((unsigned int *)t58) = 0;
    t54 = (t53 + 4);
    t60 = (t9 + t54);
    *((unsigned int *)t60) = 0;
    t55 = (t13 < 1);
    if (t55 == 1)
        goto LAB53;

LAB55:    t62 = (t13 < 1);
    if (t62 == 1)
        goto LAB54;

LAB56:    t13 = (t13 + 1);
    goto LAB51;

LAB53:    t63 = (t5 + t53);
    t56 = (t53 + 4);
    t66 = (t5 + t56);
    t57 = *((unsigned int *)t63);
    t59 = *((unsigned int *)t66);
    t61 = (t57 | t59);
    *((unsigned int *)t58) = t61;
    *((unsigned int *)t60) = *((unsigned int *)t66);
    goto LAB56;

LAB54:    t67 = (t6 + t53);
    t64 = (t53 + 4);
    t68 = (t6 + t64);
    t65 = *((unsigned int *)t67);
    t69 = *((unsigned int *)t68);
    t70 = (t65 | t69);
    *((unsigned int *)t58) = t70;
    *((unsigned int *)t60) = *((unsigned int *)t68);
    goto LAB56;

LAB58:    t31 = *((unsigned int *)t12);
    t32 = *((unsigned int *)t25);
    *((unsigned int *)t12) = (t31 | t32);

LAB60:    t13 = (t13 + 1);
    goto LAB61;

LAB59:    goto LAB60;

LAB62:    t15 = (t13 * 8);
    t4 = (t5 + t15);
    t7 = (t6 + t15);
    t12 = (t9 + t15);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t7);
    t18 = (t16 ^ t17);
    *((unsigned int *)t12) = t18;
    t19 = (t13 * 8);
    t20 = (t19 + 4);
    t21 = (t5 + t20);
    t22 = (t19 + 4);
    t23 = (t6 + t22);
    t24 = (t19 + 4);
    t25 = (t9 + t24);
    t26 = *((unsigned int *)t21);
    t27 = *((unsigned int *)t23);
    t28 = (t26 | t27);
    *((unsigned int *)t25) = t28;
    t29 = *((unsigned int *)t25);
    t30 = (t29 != 0);
    if (t30 == 1)
        goto LAB58;
    else
        goto LAB59;

LAB65:    t35 = (t13 * 8);
    t34 = (t9 + t35);
    *((unsigned int *)t34) = 0;
    t38 = (t35 + 4);
    t36 = (t9 + t38);
    *((unsigned int *)t36) = 0;
    t40 = (t13 < 1);
    if (t40 == 1)
        goto LAB66;

LAB68:    t45 = (t13 < 1);
    if (t45 == 1)
        goto LAB67;

LAB69:    t13 = (t13 + 1);
    goto LAB64;

LAB66:    t37 = (t5 + t35);
    t41 = (t35 + 4);
    t39 = (t5 + t41);
    t42 = *((unsigned int *)t37);
    t43 = *((unsigned int *)t39);
    t44 = (t42 | t43);
    *((unsigned int *)t34) = t44;
    *((unsigned int *)t36) = *((unsigned int *)t39);
    goto LAB69;

LAB67:    t58 = (t6 + t35);
    t46 = (t35 + 4);
    t60 = (t6 + t46);
    t47 = *((unsigned int *)t58);
    t50 = *((unsigned int *)t60);
    t51 = (t47 | t50);
    *((unsigned int *)t34) = t51;
    *((unsigned int *)t36) = *((unsigned int *)t60);
    goto LAB69;

LAB73:    t21 = (t73 + 4);
    *((unsigned int *)t73) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB74;

LAB75:    xsi_set_current_line(60, ng0);
    t25 = ((char*)((ng16)));
    t34 = (t0 + 9976);
    xsi_vlogvar_assign_value(t34, t25, 0, 0, 1);
    goto LAB77;

LAB80:    t36 = (t74 + 4);
    *((unsigned int *)t74) = 1;
    *((unsigned int *)t36) = 1;
    goto LAB81;

LAB82:    xsi_set_current_line(63, ng0);
    t39 = ((char*)((ng16)));
    t58 = (t0 + 10136);
    xsi_vlogvar_assign_value(t58, t39, 0, 0, 1);
    goto LAB84;

LAB87:    t21 = (t74 + 4);
    *((unsigned int *)t74) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB88;

LAB89:    *((unsigned int *)t75) = 1;
    goto LAB92;

LAB91:    t25 = (t75 + 4);
    *((unsigned int *)t75) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB92;

LAB93:    t36 = (t0 + 8936U);
    t37 = *((char **)t36);
    memset(t76, 0, 8);
    t36 = (t76 + 4);
    t39 = (t37 + 4);
    t46 = *((unsigned int *)t37);
    t47 = (t46 >> 31);
    t50 = (t47 & 1);
    *((unsigned int *)t76) = t50;
    t51 = *((unsigned int *)t39);
    t52 = (t51 >> 31);
    t53 = (t52 & 1);
    *((unsigned int *)t36) = t53;
    t58 = (t0 + 9096U);
    t60 = *((char **)t58);
    memset(t77, 0, 8);
    t58 = (t77 + 4);
    t63 = (t60 + 4);
    t54 = *((unsigned int *)t60);
    t55 = (t54 >> 31);
    t56 = (t55 & 1);
    *((unsigned int *)t77) = t56;
    t57 = *((unsigned int *)t63);
    t59 = (t57 >> 31);
    t61 = (t59 & 1);
    *((unsigned int *)t58) = t61;
    memset(t78, 0, 8);
    t66 = (t76 + 4);
    t67 = (t77 + 4);
    t62 = *((unsigned int *)t76);
    t64 = *((unsigned int *)t77);
    t65 = (t62 ^ t64);
    t69 = *((unsigned int *)t66);
    t70 = *((unsigned int *)t67);
    t79 = (t69 ^ t70);
    t80 = (t65 | t79);
    t81 = *((unsigned int *)t66);
    t82 = *((unsigned int *)t67);
    t83 = (t81 | t82);
    t84 = (~(t83));
    t85 = (t80 & t84);
    if (t85 != 0)
        goto LAB99;

LAB96:    if (t83 != 0)
        goto LAB98;

LAB97:    *((unsigned int *)t78) = 1;

LAB99:    memset(t86, 0, 8);
    t71 = (t78 + 4);
    t87 = *((unsigned int *)t71);
    t88 = (~(t87));
    t89 = *((unsigned int *)t78);
    t90 = (t89 & t88);
    t91 = (t90 & 1U);
    if (t91 != 0)
        goto LAB100;

LAB101:    if (*((unsigned int *)t71) != 0)
        goto LAB102;

LAB103:    t93 = *((unsigned int *)t75);
    t94 = *((unsigned int *)t86);
    t95 = (t93 & t94);
    *((unsigned int *)t92) = t95;
    t96 = (t75 + 4);
    t97 = (t86 + 4);
    t98 = (t92 + 4);
    t99 = *((unsigned int *)t96);
    t100 = *((unsigned int *)t97);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = *((unsigned int *)t98);
    t103 = (t102 != 0);
    if (t103 == 1)
        goto LAB104;

LAB105:
LAB106:    goto LAB95;

LAB98:    t68 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t68) = 1;
    goto LAB99;

LAB100:    *((unsigned int *)t86) = 1;
    goto LAB103;

LAB102:    t72 = (t86 + 4);
    *((unsigned int *)t86) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB103;

LAB104:    t104 = *((unsigned int *)t92);
    t105 = *((unsigned int *)t98);
    *((unsigned int *)t92) = (t104 | t105);
    t106 = (t75 + 4);
    t107 = (t86 + 4);
    t108 = *((unsigned int *)t75);
    t109 = (~(t108));
    t110 = *((unsigned int *)t106);
    t111 = (~(t110));
    t112 = *((unsigned int *)t86);
    t113 = (~(t112));
    t114 = *((unsigned int *)t107);
    t115 = (~(t114));
    t8 = (t109 & t111);
    t48 = (t113 & t115);
    t116 = (~(t8));
    t117 = (~(t48));
    t118 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t118 & t116);
    t119 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t119 & t117);
    t120 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t120 & t116);
    t121 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t121 & t117);
    goto LAB106;

LAB107:    *((unsigned int *)t122) = 1;
    goto LAB110;

LAB109:    t129 = (t122 + 4);
    *((unsigned int *)t122) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB110;

LAB111:    t134 = (t0 + 8936U);
    t135 = *((char **)t134);
    memset(t136, 0, 8);
    t134 = (t136 + 4);
    t137 = (t135 + 4);
    t138 = *((unsigned int *)t135);
    t139 = (t138 >> 31);
    t140 = (t139 & 1);
    *((unsigned int *)t136) = t140;
    t141 = *((unsigned int *)t137);
    t142 = (t141 >> 31);
    t143 = (t142 & 1);
    *((unsigned int *)t134) = t143;
    t144 = (t0 + 9816);
    t145 = (t144 + 56U);
    t146 = *((char **)t145);
    memset(t147, 0, 8);
    t148 = (t147 + 4);
    t149 = (t146 + 4);
    t150 = *((unsigned int *)t146);
    t151 = (t150 >> 31);
    t152 = (t151 & 1);
    *((unsigned int *)t147) = t152;
    t153 = *((unsigned int *)t149);
    t154 = (t153 >> 31);
    t155 = (t154 & 1);
    *((unsigned int *)t148) = t155;
    memset(t156, 0, 8);
    t157 = (t136 + 4);
    t158 = (t147 + 4);
    t159 = *((unsigned int *)t136);
    t160 = *((unsigned int *)t147);
    t161 = (t159 ^ t160);
    t162 = *((unsigned int *)t157);
    t163 = *((unsigned int *)t158);
    t164 = (t162 ^ t163);
    t165 = (t161 | t164);
    t166 = *((unsigned int *)t157);
    t167 = *((unsigned int *)t158);
    t168 = (t166 | t167);
    t169 = (~(t168));
    t170 = (t165 & t169);
    if (t170 != 0)
        goto LAB115;

LAB114:    if (t168 != 0)
        goto LAB116;

LAB117:    memset(t172, 0, 8);
    t173 = (t156 + 4);
    t174 = *((unsigned int *)t173);
    t175 = (~(t174));
    t176 = *((unsigned int *)t156);
    t177 = (t176 & t175);
    t178 = (t177 & 1U);
    if (t178 != 0)
        goto LAB118;

LAB119:    if (*((unsigned int *)t173) != 0)
        goto LAB120;

LAB121:    t181 = *((unsigned int *)t122);
    t182 = *((unsigned int *)t172);
    t183 = (t181 & t182);
    *((unsigned int *)t180) = t183;
    t184 = (t122 + 4);
    t185 = (t172 + 4);
    t186 = (t180 + 4);
    t187 = *((unsigned int *)t184);
    t188 = *((unsigned int *)t185);
    t189 = (t187 | t188);
    *((unsigned int *)t186) = t189;
    t190 = *((unsigned int *)t186);
    t191 = (t190 != 0);
    if (t191 == 1)
        goto LAB122;

LAB123:
LAB124:    goto LAB113;

LAB115:    *((unsigned int *)t156) = 1;
    goto LAB117;

LAB116:    t171 = (t156 + 4);
    *((unsigned int *)t156) = 1;
    *((unsigned int *)t171) = 1;
    goto LAB117;

LAB118:    *((unsigned int *)t172) = 1;
    goto LAB121;

LAB120:    t179 = (t172 + 4);
    *((unsigned int *)t172) = 1;
    *((unsigned int *)t179) = 1;
    goto LAB121;

LAB122:    t192 = *((unsigned int *)t180);
    t193 = *((unsigned int *)t186);
    *((unsigned int *)t180) = (t192 | t193);
    t194 = (t122 + 4);
    t195 = (t172 + 4);
    t196 = *((unsigned int *)t122);
    t197 = (~(t196));
    t198 = *((unsigned int *)t194);
    t199 = (~(t198));
    t200 = *((unsigned int *)t172);
    t201 = (~(t200));
    t202 = *((unsigned int *)t195);
    t203 = (~(t202));
    t49 = (t197 & t199);
    t204 = (t201 & t203);
    t205 = (~(t49));
    t206 = (~(t204));
    t207 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t207 & t205);
    t208 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t208 & t206);
    t209 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t209 & t205);
    t210 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t210 & t206);
    goto LAB124;

LAB125:    xsi_set_current_line(66, ng0);
    t217 = ((char*)((ng16)));
    t218 = (t0 + 10456);
    xsi_vlogvar_assign_value(t218, t217, 0, 0, 1);
    goto LAB127;

LAB130:    t21 = (t74 + 4);
    *((unsigned int *)t74) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB131;

LAB132:    *((unsigned int *)t75) = 1;
    goto LAB135;

LAB134:    t25 = (t75 + 4);
    *((unsigned int *)t75) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB135;

LAB136:    t36 = (t0 + 8936U);
    t37 = *((char **)t36);
    memset(t76, 0, 8);
    t36 = (t76 + 4);
    t39 = (t37 + 4);
    t46 = *((unsigned int *)t37);
    t47 = (t46 >> 31);
    t50 = (t47 & 1);
    *((unsigned int *)t76) = t50;
    t51 = *((unsigned int *)t39);
    t52 = (t51 >> 31);
    t53 = (t52 & 1);
    *((unsigned int *)t36) = t53;
    t58 = (t0 + 9096U);
    t60 = *((char **)t58);
    memset(t77, 0, 8);
    t58 = (t77 + 4);
    t63 = (t60 + 4);
    t54 = *((unsigned int *)t60);
    t55 = (t54 >> 31);
    t56 = (t55 & 1);
    *((unsigned int *)t77) = t56;
    t57 = *((unsigned int *)t63);
    t59 = (t57 >> 31);
    t61 = (t59 & 1);
    *((unsigned int *)t58) = t61;
    memset(t78, 0, 8);
    t66 = (t76 + 4);
    t67 = (t77 + 4);
    t62 = *((unsigned int *)t76);
    t64 = *((unsigned int *)t77);
    t65 = (t62 ^ t64);
    t69 = *((unsigned int *)t66);
    t70 = *((unsigned int *)t67);
    t79 = (t69 ^ t70);
    t80 = (t65 | t79);
    t81 = *((unsigned int *)t66);
    t82 = *((unsigned int *)t67);
    t83 = (t81 | t82);
    t84 = (~(t83));
    t85 = (t80 & t84);
    if (t85 != 0)
        goto LAB140;

LAB139:    if (t83 != 0)
        goto LAB141;

LAB142:    memset(t86, 0, 8);
    t71 = (t78 + 4);
    t87 = *((unsigned int *)t71);
    t88 = (~(t87));
    t89 = *((unsigned int *)t78);
    t90 = (t89 & t88);
    t91 = (t90 & 1U);
    if (t91 != 0)
        goto LAB143;

LAB144:    if (*((unsigned int *)t71) != 0)
        goto LAB145;

LAB146:    t93 = *((unsigned int *)t75);
    t94 = *((unsigned int *)t86);
    t95 = (t93 & t94);
    *((unsigned int *)t92) = t95;
    t96 = (t75 + 4);
    t97 = (t86 + 4);
    t98 = (t92 + 4);
    t99 = *((unsigned int *)t96);
    t100 = *((unsigned int *)t97);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = *((unsigned int *)t98);
    t103 = (t102 != 0);
    if (t103 == 1)
        goto LAB147;

LAB148:
LAB149:    goto LAB138;

LAB140:    *((unsigned int *)t78) = 1;
    goto LAB142;

LAB141:    t68 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t68) = 1;
    goto LAB142;

LAB143:    *((unsigned int *)t86) = 1;
    goto LAB146;

LAB145:    t72 = (t86 + 4);
    *((unsigned int *)t86) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB146;

LAB147:    t104 = *((unsigned int *)t92);
    t105 = *((unsigned int *)t98);
    *((unsigned int *)t92) = (t104 | t105);
    t106 = (t75 + 4);
    t107 = (t86 + 4);
    t108 = *((unsigned int *)t75);
    t109 = (~(t108));
    t110 = *((unsigned int *)t106);
    t111 = (~(t110));
    t112 = *((unsigned int *)t86);
    t113 = (~(t112));
    t114 = *((unsigned int *)t107);
    t115 = (~(t114));
    t8 = (t109 & t111);
    t48 = (t113 & t115);
    t116 = (~(t8));
    t117 = (~(t48));
    t118 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t118 & t116);
    t119 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t119 & t117);
    t120 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t120 & t116);
    t121 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t121 & t117);
    goto LAB149;

LAB150:    *((unsigned int *)t122) = 1;
    goto LAB153;

LAB152:    t129 = (t122 + 4);
    *((unsigned int *)t122) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB153;

LAB154:    t134 = (t0 + 8936U);
    t135 = *((char **)t134);
    memset(t136, 0, 8);
    t134 = (t136 + 4);
    t137 = (t135 + 4);
    t138 = *((unsigned int *)t135);
    t139 = (t138 >> 31);
    t140 = (t139 & 1);
    *((unsigned int *)t136) = t140;
    t141 = *((unsigned int *)t137);
    t142 = (t141 >> 31);
    t143 = (t142 & 1);
    *((unsigned int *)t134) = t143;
    t144 = (t0 + 9816);
    t145 = (t144 + 56U);
    t146 = *((char **)t145);
    memset(t147, 0, 8);
    t148 = (t147 + 4);
    t149 = (t146 + 4);
    t150 = *((unsigned int *)t146);
    t151 = (t150 >> 31);
    t152 = (t151 & 1);
    *((unsigned int *)t147) = t152;
    t153 = *((unsigned int *)t149);
    t154 = (t153 >> 31);
    t155 = (t154 & 1);
    *((unsigned int *)t148) = t155;
    memset(t156, 0, 8);
    t157 = (t136 + 4);
    t158 = (t147 + 4);
    t159 = *((unsigned int *)t136);
    t160 = *((unsigned int *)t147);
    t161 = (t159 ^ t160);
    t162 = *((unsigned int *)t157);
    t163 = *((unsigned int *)t158);
    t164 = (t162 ^ t163);
    t165 = (t161 | t164);
    t166 = *((unsigned int *)t157);
    t167 = *((unsigned int *)t158);
    t168 = (t166 | t167);
    t169 = (~(t168));
    t170 = (t165 & t169);
    if (t170 != 0)
        goto LAB158;

LAB157:    if (t168 != 0)
        goto LAB159;

LAB160:    memset(t172, 0, 8);
    t173 = (t156 + 4);
    t174 = *((unsigned int *)t173);
    t175 = (~(t174));
    t176 = *((unsigned int *)t156);
    t177 = (t176 & t175);
    t178 = (t177 & 1U);
    if (t178 != 0)
        goto LAB161;

LAB162:    if (*((unsigned int *)t173) != 0)
        goto LAB163;

LAB164:    t181 = *((unsigned int *)t122);
    t182 = *((unsigned int *)t172);
    t183 = (t181 & t182);
    *((unsigned int *)t180) = t183;
    t184 = (t122 + 4);
    t185 = (t172 + 4);
    t186 = (t180 + 4);
    t187 = *((unsigned int *)t184);
    t188 = *((unsigned int *)t185);
    t189 = (t187 | t188);
    *((unsigned int *)t186) = t189;
    t190 = *((unsigned int *)t186);
    t191 = (t190 != 0);
    if (t191 == 1)
        goto LAB165;

LAB166:
LAB167:    goto LAB156;

LAB158:    *((unsigned int *)t156) = 1;
    goto LAB160;

LAB159:    t171 = (t156 + 4);
    *((unsigned int *)t156) = 1;
    *((unsigned int *)t171) = 1;
    goto LAB160;

LAB161:    *((unsigned int *)t172) = 1;
    goto LAB164;

LAB163:    t179 = (t172 + 4);
    *((unsigned int *)t172) = 1;
    *((unsigned int *)t179) = 1;
    goto LAB164;

LAB165:    t192 = *((unsigned int *)t180);
    t193 = *((unsigned int *)t186);
    *((unsigned int *)t180) = (t192 | t193);
    t194 = (t122 + 4);
    t195 = (t172 + 4);
    t196 = *((unsigned int *)t122);
    t197 = (~(t196));
    t198 = *((unsigned int *)t194);
    t199 = (~(t198));
    t200 = *((unsigned int *)t172);
    t201 = (~(t200));
    t202 = *((unsigned int *)t195);
    t203 = (~(t202));
    t49 = (t197 & t199);
    t204 = (t201 & t203);
    t205 = (~(t49));
    t206 = (~(t204));
    t207 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t207 & t205);
    t208 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t208 & t206);
    t209 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t209 & t205);
    t210 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t210 & t206);
    goto LAB167;

LAB168:    xsi_set_current_line(67, ng0);
    t217 = ((char*)((ng16)));
    t218 = (t0 + 10456);
    xsi_vlogvar_assign_value(t218, t217, 0, 0, 1);
    goto LAB170;

}


extern void work_m_00000000000944954372_3341217074_init()
{
	static char *pe[] = {(void *)Initial_36_0,(void *)Always_42_1};
	xsi_register_didat("work_m_00000000000944954372_3341217074", "isim/TOP_MAIN_TB_isim_beh.exe.sim/work/m_00000000000944954372_3341217074.didat");
	xsi_register_executes(pe);
}
