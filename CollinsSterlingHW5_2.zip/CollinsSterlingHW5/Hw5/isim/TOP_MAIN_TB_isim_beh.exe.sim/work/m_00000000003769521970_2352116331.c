/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//raiderdrive.tosm.ttu.edu/users/stcollin/CollinsSterlingHW5/Hw5/IF.v";
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {0, 0};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {2150629376U, 0U};
static int ng5[] = {2, 0};
static unsigned int ng6[] = {2151677952U, 0U};
static int ng7[] = {3, 0};
static unsigned int ng8[] = {2159017984U, 0U};
static int ng9[] = {4, 0};
static unsigned int ng10[] = {2160066560U, 0U};
static int ng11[] = {5, 0};
static unsigned int ng12[] = {2161115136U, 0U};
static int ng13[] = {6, 0};
static unsigned int ng14[] = {2162163712U, 0U};
static int ng15[] = {9, 0};
static unsigned int ng16[] = {1172307983U, 0U};
static int ng17[] = {10, 0};
static unsigned int ng18[] = {1173356545U, 0U};
static int ng19[] = {15, 0};
static unsigned int ng20[] = {1644134407U, 0U};
static int ng21[] = {20, 0};
static unsigned int ng22[] = {273775616U, 0U};
static int ng23[] = {25, 0};
static unsigned int ng24[] = {1079148547U, 0U};
static int ng25[] = {27, 0};
static unsigned int ng26[] = {82248704U, 0U};
static int ng27[] = {30, 0};
static unsigned int ng28[] = {1677688833U, 0U};
static int ng29[] = {35, 0};
static unsigned int ng30[] = {1107263498U, 0U};
static int ng31[] = {37, 0};
static unsigned int ng32[] = {1625751553U, 0U};
static int ng33[] = {40, 0};
static unsigned int ng34[] = {3286237184U, 0U};



static void Initial_30_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(30, ng0);

LAB2:    xsi_set_current_line(31, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 9656);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    xsi_set_current_line(32, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 9496);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);

LAB1:    return;
}

static void Always_35_1(char *t0)
{
    char t6[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    int t8;

LAB0:    t1 = (t0 + 10824U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 11144);
    *((int *)t2) = 1;
    t3 = (t0 + 10856);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(35, ng0);

LAB5:    xsi_set_current_line(36, ng0);
    t4 = (t0 + 9096U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t5, 32, t4, 32);
    t7 = (t0 + 9496);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    xsi_set_current_line(38, ng0);
    t2 = (t0 + 9096U);
    t3 = *((char **)t2);

LAB6:    t2 = ((char*)((ng3)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng7)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng9)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng11)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng13)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng15)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng17)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng19)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng21)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng23)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng25)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng27)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng29)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng31)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng33)));
    t8 = xsi_vlog_unsigned_case_compare(t3, 32, t2, 32);
    if (t8 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB2;

LAB7:    xsi_set_current_line(39, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB9:    xsi_set_current_line(40, ng0);
    t4 = ((char*)((ng6)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB11:    xsi_set_current_line(41, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB13:    xsi_set_current_line(42, ng0);
    t4 = ((char*)((ng10)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB15:    xsi_set_current_line(43, ng0);
    t4 = ((char*)((ng12)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB17:    xsi_set_current_line(44, ng0);
    t4 = ((char*)((ng14)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB19:    xsi_set_current_line(45, ng0);
    t4 = ((char*)((ng16)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB21:    xsi_set_current_line(46, ng0);
    t4 = ((char*)((ng18)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB23:    xsi_set_current_line(47, ng0);
    t4 = ((char*)((ng20)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB25:    xsi_set_current_line(49, ng0);
    t4 = ((char*)((ng22)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB27:    xsi_set_current_line(51, ng0);
    t4 = ((char*)((ng24)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB29:    xsi_set_current_line(52, ng0);
    t4 = ((char*)((ng26)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB31:    xsi_set_current_line(54, ng0);
    t4 = ((char*)((ng28)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB33:    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng30)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB35:    xsi_set_current_line(57, ng0);
    t4 = ((char*)((ng32)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

LAB37:    xsi_set_current_line(58, ng0);
    t4 = ((char*)((ng34)));
    t5 = (t0 + 9656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    goto LAB39;

}


extern void work_m_00000000003769521970_2352116331_init()
{
	static char *pe[] = {(void *)Initial_30_0,(void *)Always_35_1};
	xsi_register_didat("work_m_00000000003769521970_2352116331", "isim/TOP_MAIN_TB_isim_beh.exe.sim/work/m_00000000003769521970_2352116331.didat");
	xsi_register_executes(pe);
}
